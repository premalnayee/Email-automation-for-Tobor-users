# RPA Individual Project Specification

## Introduction
The purpose of this document is to outline the Fundamental Project Specification that you will be working on individually within training.

This document contains any and all information required for the project, alongside marking scheme and expectations.

This project will involve concept and topics from training; more specifically, this will involve:
- Project Management
- Requirements Gathering
- Software Development Life Cycle
- RPA 

This is an *individual* project, with all of the aforementioned modules to be applied and encapsulated within a solution for a given business case.

You should treat this project as a piece of work that you must personally complete; you *must not* collaborate with your peers to complete this project.

## Background

### Scenario

**A new content aggregator app from Tobor Inc. has hit the market!**

This app *(insert your app name here)* promises to set the standard for content delivery apps and should blow the competition out of the water in terms of efficiency and accuracy. Launch proved to be extremely well received, partly because of the extremely concise, factual nature of the content delivered.

There is a problem though… initially a concept product, the app relies on manual backend interaction and administration. No-one thought this app could grow so quickly and so fast and the development department are struggling with capacity to improve the app, given their other ongoing projects.

Someone has suggested that maybe RPA could help by automating some of the administration around signups, aggregating content, the end delivery, and reporting.
The company has invested a substantial sum bringing in QAC Consultants to define and build out the automated solution.

### High Level User Journey

*Following a discussion between Sales and the Client, the detail below has been provided*

A user with the app must register before they can receive aggregated information.

Registration is straightforward but requires the user’s personal details. Due to GDPR, the company do not wish to disclose any real data to Consultants. They have provided a service however that replicates the format of user data for development purposes, a suggested dataset of 50 users should be sufficient for development and testing purposes.

The database can be found at: https://www.bestrandoms.com/ with individual data being found on the following sub-pages of the database:
```
/random-names
/random-last-names
/random-address-in-uk
```

In addition, the user provides their content subject preference.

All registration details are sent from the users email address to the Company. Access to Company email and servers is limited so a decision has been made by QAC to use Gmail email accounts to mimic users and QA Email accounts to mimic the Company.

On receipt of user registration information, the company stores the details to allow them to then send out the required content.
Users can change their details or request removal from the service at any time.

Once processed, user requests are filed accordingly, and the actions undertaken recorded for reporting purposes allowing the developers to measure the apps growth. A confirmation of the action taken is also sent to the user.

The user then starts to receive their content at the intervals detailed at registration.
 
### Backend Application Manager Responsibilities:

Apart from the manager’s other day to day concerns, a key focus is now given to the app following its successful launch. That focus is however coming at a cost with the manager spending approx. 50% of their day dealing with the ever increasing user base.

#### Registration
Handled via email then stored internally in a Database. 

#### Content Delivery
Based on the user’s preference, content is aggregated from a minimum of 3 sites with the manager ensuring that there is no repeat content and information previously sent is not sent again. Content is sent from the Company direct to the users registered email address once it has been ‘tidied’ to ensure that the content is clean and readable.
Content categories are varied and pre-defined but the Company has indicated that a smaller subset of categories (Sport, Tech or Hobbies) are acceptable for development purposes.

#### Reporting
All user data actions are recorded for Audit purposes. The manager also records several items against all content transmissions: these tend to include the User’s name and the date.

Reporting has been intermittent and only done in full when the Manager has had time. Email delivery failures have not been recorded in the past.

A daily collated report is sent as a PDF, via email, to the Company itself and stored in a local folder

### Automation Requirements

The RPA solution should be automatic and deliver content daily

Delivery of content should be after the morning cut off for new or updated registrations

The aggregated content must be clear, readable, and stored in such a way that makes retrieval or manual inspection easy

Given the pace of development, configuration files should be utilised where necessary to ease future maintainability

Given the sensitive nature of the data involved, all credentials must be stored securely

The automation must take the form of a Flowchart given the complex nature of the user journey (note: sequences can be utilised within the flow for simpler logic operations)

Full exception handling will be expected by the Company as default

The use of Orchestrator will be pivotal to providing a good insight into the ROI of the solution and how efficient it is

The Company has been promised a robust solution and an emphasis has been put on our ability to provide a dynamic, pro-active, consultancy solution adhering to the 4 guiding UiPath RPA principals
- Reliability
- Efficiency
- Maintainability
- Extensibility

### Key Stakeholders

#### Tobor Inc.
David Bradbury - Managing Director

Roberto Fernandez - Backend Application Manager and Project PM - roberto.toborinc@gmail.com

#### QA Consulting
Chris Lucas - Consultant Project Liaison - chris.lucas@qa.com

## Objective
Your overall objectives with this project are the following:
- Design requirements gathering documents for further process knowledge elicitation 
- Create and construct a full Design Process Definition (DPD) document for the automation
- Design and develop an RPA solution that will automate the process definition

As Trainers, this enables us too:
-   Objectively assess your capability with the technologies and concepts you have been taught
-   Assess your development against SFIA

## Scope
The requirements set for the project are below. 

Note that this is the minimum required for your project, which you can add onto during the project.

The requirements of the project are as follows:
- A full analysis of the processes required, broken down into current state, desired state, benefits and challenges
- A minimum of one document for gathering requirements, i.e. a questionnaire and interview document, containing as many questions deemed as necessary to elicit further knowledge of the base process requirements
- A fully documented Detailed Process Description (DPD) reflecting the current process state and the proposed automation, with as much explicit and relevant detail as possible
- A fully automated RPA solution designed and developed through UiPath

You should consider the concept of MVP (Minimum Viable Product) as you plan your project (using established planning methods e.g. Trello, Kanban, Risk Assessments), completing all the requirements above before you add extra functionality that is not specified above.

## Constraints
You must create  **at least 1 document for requirements gathering.** 

This could be a document that acts as a questionnaire, or a document that acts as an interview question document.

At least 1 content category should be used for development regardless of the number of users.

The time constraint of this application will be discussed when the specification is given out, as this can fluctuate based on several factors.

The other constraint for this is certain technology that needs to be used. 

The application needs to utilise the technology discussed during the training modules (UiPath). 

## Deliverable
The final deliverable for this project is the completed RPA application with full supporting documentation.

The documentation must be provided as a business-facing document (i.e. Word document or equivalent). 

A presentation of work will be required at the end of the deadline, this will be recorded to be used as part of your individual portfolio's that will be marketed to potential clients.

You may also be required to produce update reports of any designs and work created throughout the duration of the project.