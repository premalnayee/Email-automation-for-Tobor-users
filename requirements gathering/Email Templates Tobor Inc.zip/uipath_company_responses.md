# RPA Individual Project Specification

## Company Responses

### **What does an average content delivery to a user  look like in terms of size and detail?**
Historically, content has been short bulletins of information containing no more than a few sentences. In some cases, these have been even shorter and represented small facts related to the user’s content choice. The goal is to send out informative content which does not detract from the user’s available time, thereby increasing consumption.

### **In terms of personal user data, what fields are captured during the registration process?**
Personal Details consist of a user’s first name, last name, their address, phone number details, email address, content (subject) preference and content frequency (daily or weekdays only).

### **Following registration, how are the user's details stored at the Company?**
Personal Details are stored in a database and assigned a unique ID. For development purposes and without access to the Company’s systems, an appropriate storage method must be assumed by QAC Consultants.

### **What format do user requests for change or removal take?**
Any requests for change or removal from the system involves the Company receiving an email with a subject of ‘CHANGE’ or ‘DELETE’. Note there have been some cases in the past where a user has tried to delete themselves by changing their information to be blank. Since then all user detail fields are mandatory.

### **After processing a user request, how is the request filed or archived?**
User request emails are typically archived in suitable folders so as to keep a record of these requests for Audit purposes.

### **After processing a user request, which actions are required to be stored for reporting purposes?**
Aside from keeping user request emails, the action requested, and the execution of that action is recorded to act as a reference in the event of a customer query.

### **Content is described as being transmitted "at intervals", chosen by the user at registration. What are the interval options?**
Intervals remain to be daily or weekdays only but there is some discussion about expanding that out to include a weekly option as well.

### **Which Database are user registration details entered into?**
Without access to the Company’s systems it has been agreed that the QAC Consultants will choose an appropriate storage medium.

### **Is there a defined dataset that is recorded against content transmissions?**
Ad-hoc reporting has become an issue so a return to the standard reporting items is sought. For user requests these include the user’s names, email address, Date/Time of request, summary of changed items. For content transmissions these are user’s names, transmission date time, content preference and the first piece of content.

### **The Daily Collated Report is detailed as being held in a 'local folder'. Which folder is that?**
Prior to go live the Company is happy to have this data stored locally on development machines, given the lack of real data in the development scenarios.

### **Can you provide details of the content delivery cut-off?**
Cut-off is 1130am at which point all user requests must be completed prior to collating and transmitting content. Any subsequent user requests must be held for processing the next working day.

### **How is the aggregated content stored to ensure it is easily retrieved or inspected?**
The Company have no preference apart from stating that the retrieval or inspection of the data must be easy.