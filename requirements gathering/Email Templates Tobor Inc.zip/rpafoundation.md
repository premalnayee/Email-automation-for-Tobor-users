# Marking Scheme

Below are the skills that we will be evaluating for this assessment.
These skills are as described in the SFIA 7 framework; please see below
if you wish to have more information:

[https://www.sfia-online.org/en/framework](https://www.sfia-online.org/en/framework)

The skills this assessment will discussed are the following:
- Programming/software development
- Software Design
- Testing
- Business Analysis
- Requirements Definition and Management

## Programming/Software Development
Score out of 15.

Designs, codes, verifies, tests, documents, amends and refactors simple programs/scripts. 

Applies agreed standards and tools, to achieve a well-engineered result. 

Reviews own work.

Below is the list of criteria that will be assessed from your deliverable:

| SFIA Skill                                                     | Rating   | Details                                                                                    |
|----------------------------------------------------------------|----------|--------------------------------------------------------------------------------------------|
| Designs, codes and verifies simple programs/scripts            | 1        | Software is missing functionality in major areas for the MVP (Could be a CRUD application) |   
|                                                                | 2        | Software functionality is working in areas but is not a fully working product              |   
|                                                                | 3        | Software is functional in all necessary areas (MVP) but still has small bugs and/or errors |
|                                                                | 4        | Software is functional in all Major areas but still has small bugs and/or errors           |
|                                                                | 5        | Software is fully functional in all relevant areas                                         |  
| Tests, documents, amends and refactors simple programs/scripts | 1        | No tests implemented and designs documented were not implemented. Best practices not adhered to in the project. |
|                                                                | 2        | Tests were beginning to be implemented, parts of the project adhered to best practices but not consistently throughout the software. |
|                                                                | 3        | Software has been tested in the most important areas, (judged by test coverage) with basic functions being tested. Best practices were adhered to for most areas of the project |
|                                                                | 4        | Software has been tested in most relevant areas, best practices were consistently adhered to throughout the project |
|                                                                | 5        | Software has been tested in all areas, with best practices and refactoring adhered to and implemented throughout the project |
| Applies agreed standards and tools, to achieve a well-engineered result | 1 | Tools and workflows discussed in software documentation around design, however not implemented |
| 																		  | 2 | Tools and workflows are referred to within the project, but the implementation is minimal |
|                                        								  | 3 | Tools and workflows discussed in documentation are implemented throughout the project at an acceptable level, but more exploration could have occurred |
|																		  | 4 | Tools and workflows discussed in documentation are implemented throughout the project at a high level |
|																		  | 5  | All best practices, tools and workflows taught are used successfully to a high level from design to final product |

## Software Design
Score out of 10.

The specification and design of software to meet defined requirements by following agreed design standards and principles. 

The definition of software, components, interfaces and related characteristics.

Below is the list of criteria that will be assessed from your deliverable:

| SFIA Skill                                                     | Rating   | Details                                                                                    |
|----------------------------------------------------------------|----------|--------------------------------------------------------------------------------------------|
| Create & document designs for applications applying agreed modelling techniques & standards | 1        | No designs created and/or provided for the application |
|                                                                | 2        | Simple designs provided but not adhering to agreed standards and patterns |
|                                                                | 3        | One simple design provided meeting the agreed standards and patterns |
|                                                                | 4        | More extensive Designs provided on both a system level and component level |
|                                                                | 5        | Evolution of designs evident as the project progressed in all aspects |
| Creates and documents the development and/or deployment of an application, applying agreed standards and tools | 1        | No documentation present for the application that has been built |
|                                                                | 2        | Documentation exists but does not follow a clear and coherent structure |
|                                                                | 3        | Structured documentation with relevant content |
|                                                                | 4        | In depth documentation that explores the application to a high level |
|                                                                | 5        | Further analysis – licensing – contributors – acknowledgements - versioning |

## Testing
Score out of 10.

The planning, design, management, execution and reporting of tests, using appropriate testing tools and techniques and conforming to agreed process standards and industry specific regulations.

Below is the list of criteria that will be assessed from your deliverable:

| SFIA Skill                                                       | Rating   | Details                                                                                    |
|------------------------------------------------------------------|----------|--------------------------------------------------------------------------------------------|
| Designs test cases and creates test scripts and supporting data  | 1        | No tests written and 0% code coverage reached |
|                      											   | 2        | Only a few tests written, no results have been acknowledged |
|                      											   | 3        | An acceptable level of test coverage met, utilising an acceptable range of tests |
|                       										   | 4        | A good level of test coverage met, utilising a good range of tests |
|                       										   | 5        | A great level of test coverage met, utilising a broad range of tests |
| Analyses and reports test activities and results                 | 1        | No analysis of what was tested vs what wasn't tested and why. No summary to overall results of testing |
|                      											   | 2        | Some analysis as to what was tested. Rough details on the testing results |
|                      											   | 3        | Some analysis as to what was tested and why. Summary of overall results is present but isn't in much detail |
|                       										   | 4        | Analysis as to what was tested, what was out of scope and the reasons behind these decisions. Summary of overall results is present |
|                       										   | 5        | Analysis as to what should be tested and what is out of scoped is discussed in detail. Summary of overall results present with in-depth reports |

## Business Analysis
Score out of 10.

The methodical investigation, analysis, review and documentation of all or part of a business in terms of business goals, objectives, functions and processes, the information used and the data on which the information is based.

| SFIA Skill                                                       | Rating   | Details                                                                                    |
|------------------------------------------------------------------|----------|--------------------------------------------------------------------------------------------|
| Investigates needs, problems, and opportunities for RPA	       | 1	      | No needs, problems or opportunities for RPA identified|
|                                                                  | 2        | Minimal analysis into needs for RPA, lack of direction for identified problems or opportunities|
|                                                                  | 3        | Needs, problems and opportunities for RPA discussed at a high level, process improvement discussed at high level |
|                                                                  | 4        | Needs, problems and opportunities discussed in detail, structured comparison between current implementation and RPA implementation, process improvement discussed thoroughly |
|                                                                  | 5        | Critical analysis of needs, problems and opportunities,with comparison of implementation choices, process improvement discussed at activity level with mentioned assumptions  |
| Assists in defining acceptance tests & expectations for chosen automation  | 1        | Business rules not acknowledged, severe lack of test cases defined |
|                                                                            | 2        | Business rules acknowledged, test cases for some business rule scenario |
|                                                                            | 3        | Business rules acknowledged, test cases defined for each business rule scenario |
|                                                                            | 4        | Business rules acknowledged, tests cases defined for as-is and to-be process |
|                                                                            | 5        | Business rules acknowledged, tests cases defined for as-is and to-be process, analysis of process improvement within business cases provided |


## Requirements Definition and Management
Score out of 10.

The elicitation, analysis, specification and validation of requirements and constraints to a level that enables effective development and operations of new or changed software, systems, processes, products and services.

Below is the list of criteria that will be assessed from your deliverable:

| SFIA Skill                                                       | Rating   | Details                                                                                    |
|------------------------------------------------------------------|----------|--------------------------------------------------------------------------------------------|
| Apply techniques to elicit and document detailed requirements    | 1        | No requirements gathering documentation created |
|                                                                  | 2        | Documents created, questions lack direction but could be used to uncover basic, high-level information. Minimal analysis of responses.
|                                                                  | 3        | Documents created, primarily closed questions. Analysis of responses at an average level |
|                                                                  | 4        | Documents created, mix of closed and open questions. Critical analysis of responses with some identification of missed areas |
|                                                                  | 5        | Documents created with structured narrative to elicit information throughout, primarily open questions. Critical analysis of responses with full identification of missed areas & follow-up questions |
| Assists in the creation of a requirements baseline document (DPD)| 1        | No documentation around current process created |
|                                                                  | 2        | Documentation around current process gives high-level overview, lack of detail throughout |
|                                                                  | 3        | Documentation details current process with all relevant activities |
|                                                                  | 4        | Documentation details current process with all relevant activities and potential pain points to improve |
|                                                                  | 5        | Documentation details current process with all relevant activities and factors - Revision History, contributors, stakeholders, automation proposal, exceptions, triggers and potential pain points to improve




